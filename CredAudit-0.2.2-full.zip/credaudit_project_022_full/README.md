# CredAudit (v0.2.2)

CredAudit scans local/shared folders for secrets (passwords, tokens, API keys, private keys, etc.).
Supports .txt, .json, .env, .docx, .pdf, .xlsx. Optional ZIP/RAR archive scanning.

## Key features
- Multithreading (file discovery) + multiprocessing (scanning)
- Config-driven (`config.yaml`) + CLI overrides
- Resilient: skips unreadable/locked files
- Caching: skip unchanged files (mtime+size)
- Filters: `--include-ext`, `--include-glob`, `--exclude-glob`, `--ignore-file`
- `--list` mode (dry run), `--timestamp`, `--fail-on {Low,Medium,High}`
- Output formats: JSON, CSV, HTML, SARIF
- HTML report redacts secrets
- **v0.2.2**: multi-encoding for text, verbose skip-reason logging, optional ZIP/RAR scanning

See CredAudit-Quickstart.pdf for install & usage.
