import os, zipfile
try:
    import rarfile
except ImportError:
    rarfile = None
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from typing import List, Tuple, Any, Dict
from .utils.common import iter_files, match_globs, normalize_exts
from .parsers.extract import extract_text_from_file
from .detection.scan import scan_text, serialize_findings
from .cache import ScanCache
from .scoring import SEVERITY_ORDER

SUPPORTED_SCAN_EXTS = {".txt", ".json", ".env", ".docx", ".pdf", ".xlsx"}

def _should_include(path: str, include_exts: List[str], include_globs: List[str], exclude_globs: List[str]) -> bool:
    if include_exts:
        ext = os.path.splitext(path)[1].lower()
        if ext not in include_exts:
            return False
    return match_globs(path, include_globs, exclude_globs)

def collect_files(root: str, include_exts: List[str], include_globs: List[str], exclude_globs: List[str], threads: int = 8,
                  ignore_globs: List[str] | None = None, max_size_bytes: int | None = None, verbose: bool = False) -> List[str]:
    include_exts = normalize_exts(include_exts)
    ignore_globs = ignore_globs or []
    candidates: List[str] = []
    with ThreadPoolExecutor(max_workers=threads) as tp:
        futures = []
        paths = list(iter_files(root))
        for p in paths:
            futures.append(tp.submit(_should_include, p, include_exts, include_globs, exclude_globs))
        for p, fut in zip(paths, futures):
            try:
                if fut.result():
                    inc = True
                    for pat in ignore_globs:
                        import fnmatch
                        if fnmatch.fnmatch(p.replace('\\','/'), pat):
                            inc = False; break
                    if inc and max_size_bytes is not None:
                        try:
                            if os.path.getsize(p) > max_size_bytes:
                                inc = False
                        except Exception:
                            pass
                    if inc:
                        candidates.append(p)
                        if verbose: print(p)
            except Exception:
                continue
    return candidates

def _scan_one(args: Tuple[str, int, float]) -> Tuple[str, List[Dict[str, Any]], str]:
    path, entropy_min_len, entropy_thresh = args
    try:
        text = extract_text_from_file(path)
        if text is None:
            return (path, [], "unreadable")
        findings = scan_text(path, text, entropy_min_len, entropy_thresh)
        return (path, serialize_findings(findings), "ok")
    except Exception:
        return (path, [], "error")

def scan_archives(path: str, entropy_min_len: int, entropy_thresh: float, verbose: bool) -> List[Dict[str, Any]]:
    findings_all: List[Dict[str, Any]] = []
    ext = os.path.splitext(path)[1].lower()
    if ext == ".zip":
        try:
            with zipfile.ZipFile(path) as z:
                for name in z.namelist():
                    inner_ext = os.path.splitext(name)[1].lower()
                    if inner_ext in SUPPORTED_SCAN_EXTS:
                        try:
                            data = z.read(name)
                            text = data.decode("utf-8", errors="ignore")
                            findings_all.extend(serialize_findings(scan_text(f"{path}:{name}", text, entropy_min_len, entropy_thresh)))
                            if verbose: print(f"[SCAN] {path}:{name}")
                        except Exception as e:
                            if verbose: print(f"[SKIP] {path}:{name} → unreadable ({e})")
                    else:
                        if verbose: print(f"[SKIP] {path}:{name} → unsupported extension inside archive")
        except Exception as e:
            if verbose: print(f"[SKIP] {path} → archive error ({e})")
    elif ext == ".rar" and rarfile:
        try:
            with rarfile.RarFile(path) as r:
                for info in r.infolist():
                    name = info.filename
                    inner_ext = os.path.splitext(name)[1].lower()
                    if inner_ext in SUPPORTED_SCAN_EXTS:
                        try:
                            data = r.read(name)
                            text = data.decode("utf-8", errors="ignore")
                            findings_all.extend(serialize_findings(scan_text(f"{path}:{name}", text, entropy_min_len, entropy_thresh)))
                            if verbose: print(f"[SCAN] {path}:{name}")
                        except Exception as e:
                            if verbose: print(f"[SKIP] {path}:{name} → unreadable ({e})")
                    else:
                        if verbose: print(f"[SKIP] {path}:{name} → unsupported extension inside archive")
        except Exception as e:
            if verbose: print(f"[SKIP] {path} → archive error ({e})")
    elif ext == ".rar":
        if verbose: print(f"[SKIP] {path} → rarfile module not available")
    return findings_all

def scan_paths(paths: List[str], output_dir: str, formats: List[str], timestamp: bool, cache_file: str,
               entropy_min_len: int, entropy_thresh: float, workers: int | None,
               fail_on: str | None, scan_archives_flag: bool, verbose: bool):
    os.makedirs(output_dir, exist_ok=True)
    cache_path = cache_file if os.path.isabs(cache_file) else os.path.join(output_dir, cache_file)
    cache = ScanCache(cache_path)

    to_scan = [p for p in paths if not cache.is_unchanged(p)]

    findings_all: List[Dict[str, Any]] = []
    with ProcessPoolExecutor(max_workers=workers or os.cpu_count() or 2) as pp:
        futures = {}
        for p in to_scan:
            ext = os.path.splitext(p)[1].lower()
            if scan_archives_flag and ext in (".zip", ".rar"):
                # archives scanned in main process (streaming decode), no cache update here
                findings_all.extend(scan_archives(p, entropy_min_len, entropy_thresh, verbose))
                cache.update(p)
            else:
                futures[pp.submit(_scan_one, (p, entropy_min_len, entropy_thresh))] = p

        for fut in as_completed(futures):
            p = futures[fut]
            try:
                path, findings, status = fut.result()
                if status == "ok" and findings:
                    findings_all.extend(findings)
                if status in ("ok", "unreadable"):
                    cache.update(p)
                elif verbose and status == "error":
                    print(f"[SKIP] {p} → error during scan")
            except Exception as e:
                if verbose:
                    print(f"[SKIP] {p} → exception {e}")

    import datetime as _dt
    stamp = "_" + _dt.datetime.now().strftime("%Y%m%d_%H%M%S") if timestamp else ""
    base = os.path.join(output_dir, f"report{stamp}")

    if "json" in formats:
        from .exporters.json_exporter import export_json
        export_json(findings_all, base + ".json")
    if "csv" in formats:
        from .exporters.csv_exporter import export_csv
        export_csv(findings_all, base + ".csv")
    if "html" in formats:
        from .exporters.html_exporter import export_html
        export_html(findings_all, base + ".html")
    if "sarif" in formats:
        from .exporters.sarif_exporter import export_sarif
        export_sarif(findings_all, base + ".sarif")

    exit_code = 0
    if fail_on:
        worst = "Ignore"
        for f in findings_all:
            sev = f.get("severity", "Low")
            if SEVERITY_ORDER.get(sev, 0) > SEVERITY_ORDER.get(worst, 0):
                worst = sev
        if SEVERITY_ORDER.get(worst, 0) >= SEVERITY_ORDER.get(fail_on, 0) and findings_all:
            exit_code = 3

    cache.save()
    return findings_all, exit_code
