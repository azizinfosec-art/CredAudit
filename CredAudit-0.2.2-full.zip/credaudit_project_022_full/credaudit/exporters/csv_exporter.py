import csv
FIELDS = ["file", "rule", "redacted", "severity", "line", "context"]
def export_csv(findings, path):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for it in findings:
            row = {k: it.get(k, "") for k in FIELDS}
            w.writerow(row)
