from jinja2 import Template

HTML_TMPL = Template("""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>CredAudit Report</title>
<style>
  body { font-family: Arial, Helvetica, sans-serif; margin: 20px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border: 1px solid #ddd; padding: 8px; font-size: 14px; }
  th { background: #f4f4f4; text-align: left; }
  tr.high { background: #ffe5e5; }
  tr.medium { background: #fff6e0; }
  tr.low { background: #eef7ff; }
  .muted { color: #666; font-size: 12px; }
</style>
</head>
<body>
<h2>CredAudit Report</h2>
{% set high = findings | selectattr('severity', 'equalto', 'High') | list | length %}
{% set med = findings | selectattr('severity', 'equalto', 'Medium') | list | length %}
{% set low = findings | selectattr('severity', 'equalto', 'Low') | list | length %}
<p><strong>Summary:</strong> High={{ high }}, Medium={{ med }}, Low={{ low }}, Total={{ findings|length }}</p>
<table>
  <thead>
    <tr>
      <th>Severity</th>
      <th>Rule</th>
      <th>Redacted Secret</th>
      <th>File</th>
      <th>Line</th>
      <th>Context</th>
    </tr>
  </thead>
  <tbody>
  {% for f in findings %}
    {% set cls = 'high' if f.severity=='High' else ('medium' if f.severity=='Medium' else 'low') %}
    <tr class="{{ cls }}">
      <td>{{ f.severity }}</td>
      <td>{{ f.rule }}</td>
      <td><code>{{ f.redacted }}</code></td>
      <td>{{ f.file }}</td>
      <td>{{ f.line }}</td>
      <td><pre style="white-space: pre-wrap; margin: 0">{{ f.context }}</pre></td>
    </tr>
  {% endfor %}
  </tbody>
</table>
</body>
</html>
""")

def export_html(findings, path):
    html = HTML_TMPL.render(findings=findings)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
