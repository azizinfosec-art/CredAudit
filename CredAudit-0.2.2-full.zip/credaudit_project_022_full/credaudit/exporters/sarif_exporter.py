import json
def export_sarif(findings, path):
    runs = [{
        "tool": {"driver": {"name": "CredAudit", "informationUri": "https://example.com", "rules": []}},
        "results": []
    }]
    for f in findings:
        runs[0]["results"].append({
            "ruleId": f.get("rule","GenericSecret"),
            "level": "error" if f.get("severity")=="High" else ("warning" if f.get("severity")=="Medium" else "note"),
            "message": {"text": f"{f.get('rule')} detected in {f.get('file')} (line {f.get('line')})"},
            "locations": [{
                "physicalLocation": {"artifactLocation": {"uri": f.get("file")}, "region": {"startLine": f.get("line", 1)}}
            }],
            "partialFingerprints": {"redacted": f.get("redacted","")}
        })
    sarif = {"version":"2.1.0","$schema":"https://schemastore.azurewebsites.net/schemas/json/sarif-2.1.0.json","runs":runs}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(sarif, f, ensure_ascii=False, indent=2)
