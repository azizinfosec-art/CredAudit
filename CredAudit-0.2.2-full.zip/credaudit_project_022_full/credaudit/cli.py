import sys, argparse, pathlib, os
from .config import Config, DEFAULT_CONFIG_PATH
from .orchestrator import collect_files, scan_paths
from .detection.rules import build_rules

def print_rules():
    for r in build_rules():
        print(f"- {r.name}: {r.description}\n  e.g., {r.example}\n")

def do_validate(cfg: Config):
    print("Configuration OK")
    print(f"Enabled parsers: .txt .json .env .docx .pdf .xlsx")
    print(f"Workers: {cfg.workers or 'auto'} | Threads: {cfg.threads}")
    print(f"Include extensions: {', '.join(cfg.include_ext)}")
    if cfg.include_glob:
        print(f"Include globs: {', '.join(cfg.include_glob)}")
    if cfg.exclude_glob:
        print(f"Exclude globs: {', '.join(cfg.exclude_glob)}")

def parse_common_args(p: argparse.ArgumentParser):
    p.add_argument("-p", "--path", required=False, help="File or directory to scan")
    p.add_argument("-o", "--output-dir", default="./credaudit_out", help="Output directory")
    p.add_argument("--formats", nargs="+", choices=["json", "csv", "html", "sarif"], default=["json", "csv", "html"])
    p.add_argument("--include-ext", nargs="*", help="Only scan these extensions (.txt .json .env ...)")
    p.add_argument("--include-glob", action="append", default=[], help="Include files matching glob (repeatable)")
    p.add_argument("--exclude-glob", action="append", default=[], help="Exclude files matching glob (repeatable)")
    p.add_argument("--ignore-file", help="Path to .credauditignore glob list")
    p.add_argument("--max-size", type=int, help="Skip files larger than MB")
    p.add_argument("--threads", type=int, help="Threads for file discovery")
    p.add_argument("--workers", type=int, help="Processes for scanning")
    p.add_argument("--list", action="store_true", help="Dry-run: only list files")
    p.add_argument("--timestamp", action="store_true", help="Append timestamp to report filename")
    p.add_argument("--fail-on", choices=["Low", "Medium", "High"], help="Exit non-zero if any finding >= threshold")
    p.add_argument("--config", default=DEFAULT_CONFIG_PATH, help="Path to config.yaml")
    p.add_argument("--entropy-min-length", type=int, dest="entropy_min_length", help="Entropy min token length")
    p.add_argument("--entropy-threshold", type=float, dest="entropy_threshold", help="Entropy threshold")
    p.add_argument("--cache-file", help="Cache file name/path")
    p.add_argument("--verbose", action="store_true", help="Verbose logging with skip reasons")
    p.add_argument("--scan-archives", action="store_true", help="Scan inside ZIP/RAR archives (optional)")
    p.add_argument("--archive-depth", type=int, default=1, help="How deep to unpack nested archives (reserved)")
    return p

def main(argv=None) -> int:
    argv = argv or sys.argv[1:]
    parser = argparse.ArgumentParser(
        prog="credaudit",
        description="CredAudit secret scanner",
        formatter_class=argparse.RawTextHelpFormatter
    )
    sub = parser.add_subparsers(dest="command")

    rules_p = sub.add_parser("rules", help="Show built-in detection rules")
    validate_p = sub.add_parser("validate", help="Check config and show enabled parsers")
    validate_p.add_argument("--config", default=DEFAULT_CONFIG_PATH, help="Path to config.yaml")

    scan_p = sub.add_parser("scan", help="Run a scan")
    parse_common_args(scan_p)

    args = parser.parse_args(argv)
    cmd = args.command

    if cmd == "rules":
        print_rules(); return 0
    elif cmd == "validate":
        cfg = Config.from_yaml(args.config or DEFAULT_CONFIG_PATH)
        do_validate(cfg); return 0
    elif cmd == "scan":
        cfg = Config.from_yaml(args.config or DEFAULT_CONFIG_PATH)
        cfg.merge_cli_overrides(vars(args))

        # ignore globs
        ignore_globs = []
        if args.ignore_file:
            try:
                ignore_globs = [ln.strip() for ln in pathlib.Path(args.ignore_file).read_text(encoding="utf-8").splitlines() if ln.strip() and not ln.strip().startswith("#")]
            except Exception:
                ignore_globs = []
        else:
            pth = pathlib.Path(".credauditignore")
            if pth.exists():
                ignore_globs = [ln.strip() for ln in pth.read_text(encoding="utf-8").splitlines() if ln.strip() and not ln.strip().startswith("#")]

        max_size_bytes = args.max_size * 1024 * 1024 if args.max_size else None
        path = args.path or "."
        files = collect_files(path, cfg.include_ext, cfg.include_glob, cfg.exclude_glob, threads=cfg.threads,
                              ignore_globs=ignore_globs, max_size_bytes=max_size_bytes, verbose=args.verbose)

        if args.list:
            for f in files:
                print(f)
            return 0

        findings, exit_code = scan_paths(
            paths=files,
            output_dir=args.output_dir,
            formats=args.formats,
            timestamp=args.timestamp,
            cache_file=cfg.cache_file,
            entropy_min_len=cfg.entropy_min_length,
            entropy_thresh=cfg.entropy_threshold,
            workers=cfg.workers,
            fail_on=args.fail_on,
            scan_archives_flag=args.scan_archives,
            verbose=args.verbose,
        )
        print(f"Scanned {len(files)} files; Findings: {len(findings)}")
        return exit_code
    else:
        parser.print_help(); return 0

if __name__ == "__main__":
    raise SystemExit(main())
