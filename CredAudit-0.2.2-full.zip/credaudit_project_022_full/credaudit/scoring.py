SEVERITY_ORDER = {"Ignore": 0, "Low": 1, "Medium": 2, "High": 3}
BASE_SEVERITY = {
    "PrivateKey": "High",
    "AWSAccessKeyID": "High",
    "AWSSecretKeyCandidate": "High",
    "GitHubToken": "High",
    "GCPKeyCandidate": "High",
    "SlackToken": "Medium",
    "JWT": "Medium",
    "AzureConnString": "Medium",
    "PasswordAssignment": "Medium",
    "HighEntropyString": "Low",
    "GoogleAPIKey": "Medium",
    "SlackWebhook": "Medium",
    "APIKeyGeneric": "Medium",
}
def severity_for_rule(rule_name: str) -> str:
    return BASE_SEVERITY.get(rule_name, "Low")
