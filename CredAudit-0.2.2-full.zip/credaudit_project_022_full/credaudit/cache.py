import json, os
from typing import Dict, Tuple
class ScanCache:
    def __init__(self, cache_path: str):
        self.cache_path = cache_path
        self._data: Dict[str, Dict] = {}
        self._load()
    def _load(self):
        if os.path.exists(self.cache_path):
            try:
                with open(self.cache_path, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except Exception:
                self._data = {}
    def save(self):
        try:
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    def get_sig(self, path: str) -> Tuple[int, int]:
        try:
            st = os.stat(path)
            return int(st.st_mtime), int(st.st_size)
        except Exception:
            return (0, 0)
    def is_unchanged(self, path: str) -> bool:
        mtime, size = self.get_sig(path)
        entry = self._data.get(path)
        if not entry: return False
        return entry.get("mtime") == mtime and entry.get("size") == size
    def update(self, path: str):
        mtime, size = self.get_sig(path)
        self._data[path] = {"mtime": mtime, "size": size}
