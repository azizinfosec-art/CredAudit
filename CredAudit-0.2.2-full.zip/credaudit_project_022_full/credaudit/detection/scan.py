import re
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
from .rules import build_rules, extra_validators
from ..utils.entropy import shannon_entropy
from ..scoring import severity_for_rule

@dataclass
class Finding:
    file: str
    rule: str
    match: str
    redacted: str
    context: str
    severity: str
    line: int

def scan_text(file_path: str, text: str, entropy_min_len: int = 20, entropy_thresh: float = 4.0) -> List[Finding]:
    findings: List[Finding] = []
    if not text:
        return findings
    lines = text.splitlines()
    joined = text

    for r in build_rules():
        for m in r.pattern.finditer(joined):
            s = m.group(0)
            if not extra_validators(r.name, s):
                continue
            start = m.start()
            line_no = joined.count("\n", 0, start) + 1
            ctx = lines[line_no - 1][:200] if 0 < line_no <= len(lines) else s[:200]

            # false positive suppression
            low_val = s.lower()
            for bad in ["username=", "user=", "name=", "email="]:
                if bad in low_val:
                    break
            else:
                for trivial in ["admin", "guest", "test", "none", "changeme"]:
                    if trivial in low_val:
                        break
                else:
                    severity = severity_for_rule(r.name)
                    redacted = s[:4] + "**********" + s[-4:] if len(s) > 8 else "**********"
                    findings.append(Finding(
                        file=file_path, rule=r.name, match=s, redacted=redacted, context=ctx, severity=severity, line=line_no
                    ))

    tokens = re.findall(r"[A-Za-z0-9+/=_-]{20,}", joined)
    for t in tokens:
        if len(t) >= entropy_min_len:
            ent = shannon_entropy(t)
            if ent >= entropy_thresh:
                pos = joined.find(t)
                line_no = joined.count("\n", 0, pos) + 1
                ctx = lines[line_no - 1][:200] if 0 < line_no <= len(lines) else t[:200]
                redacted = t[:4] + "**********" + t[-4:] if len(t) > 8 else "**********"
                findings.append(Finding(
                    file=file_path, rule="HighEntropyString", match=t, redacted=redacted,
                    context=ctx, severity="Low", line=line_no
                ))
    return findings

def serialize_findings(findings: List[Finding]) -> List[Dict[str, Any]]:
    return [asdict(f) for f in findings]
