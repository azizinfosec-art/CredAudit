\
import re
from dataclasses import dataclass
from typing import List, Pattern
from ..utils.entropy import shannon_entropy

@dataclass
class Rule:
    name: str
    pattern: Pattern
    description: str
    example: str

def build_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(Rule(
        name="PrivateKey",
        pattern=re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----[\s\S]+?-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", re.MULTILINE),
        description="PEM-encoded private key material",
        example="-----BEGIN PRIVATE KEY----- ... -----END PRIVATE KEY-----",
    ))
    rules.append(Rule(
        name="AWSAccessKeyID",
        pattern=re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"),
        description="AWS Access Key ID",
        example="AKIAIOSFODNN7EXAMPLE",
    ))
    rules.append(Rule(
        name="AWSSecretKeyCandidate",
        pattern=re.compile(r"(?<![A-Za-z0-9+/=])([A-Za-z0-9/+=]{40})(?![A-Za-z0-9/+=])"),
        description="Possible AWS Secret Access Key (40 chars base64ish)",
        example="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    ))
    rules.append(Rule(
        name="GitHubToken",
        pattern=re.compile(r"\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36}\b"),
        description="GitHub token",
        example="ghp_abcdefghijklmnopqrstuvwxyz0123456789",
    ))
    rules.append(Rule(
        name="SlackToken",
        pattern=re.compile(r"\b(xox[abprs]-[A-Za-z0-9-]{10,48})\b"),
        description="Slack legacy token",
        example="xoxb-123456789012-ABCDEFGHIJKLmnopqrst",
    ))
    rules.append(Rule(
        name="JWT",
        pattern=re.compile(r"\beyJ[0-9A-Za-z_-]+?\.[0-9A-Za-z_-]+?\.[0-9A-Za-z_-]{8,}\b"),
        description="JSON Web Token",
        example="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    ))
    rules.append(Rule(
        name="AzureConnString",
        pattern=re.compile(r"(AccountKey|SharedAccessKey|PrimaryKey)\s*=\s*([A-Za-z0-9+/=]{20,})"),
        description="Azure storage/service bus connection string key",
        example="AccountKey=AbCDefg123...",
    ))
    rules.append(Rule(
        name="GCPKeyCandidate",
        pattern=re.compile(r"\"(private_key|private_key_id)\"\s*:\s*\"([^\"]{16,})\""),
        description="GCP Service Account key fields",
        example="\"private_key_id\": \"abcd1234...\"",
    ))
    rules.append(Rule(
        name="PasswordAssignment",
        pattern=re.compile(
            r"\b(password|pass|pwd|secret|apikey|api_key|token)\b\s*(=|:|=>|:=|->|：)\s*[\"']?([^\s\"']{4,})[\"']?",
            re.IGNORECASE
        ),
        description="Password/secret assignment with multiple separators and quoted values",
        example="password: \"secret123\"",
    ))
    rules.append(Rule(
        name="GoogleAPIKey",
        pattern=re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"),
        description="Google API key",
        example="AIzaSyA....(35 chars)...",
    ))
    rules.append(Rule(
        name="SlackWebhook",
        pattern=re.compile(r"https://hooks\.slack\.com/services/[A-Za-z0-9/_-]{20,}"),
        description="Slack Incoming Webhook URL",
        example="https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX",
    ))
    rules.append(Rule(
        name="APIKeyGeneric",
        pattern=re.compile(r"\b(sk|pk)-[A-Za-z0-9]{10,}\b"),
        description="Generic API key (sk-/pk- style)",
        example="sk-abc1234567890",
    ))

    return rules

def validate_jwt(token: str) -> bool:
    import json, base64
    try:
        header_b64, payload_b64, sig = token.split(".")
        def b64d(s):
            pad = '=' * (-len(s) % 4)
            return base64.urlsafe_b64decode(s + pad)
        header = json.loads(b64d(header_b64))
        payload = json.loads(b64d(payload_b64))
        return isinstance(header, dict) and "alg" in header and isinstance(payload, dict)
    except Exception:
        return False

def extra_validators(name: str, match_str: str) -> bool:
    if name == "JWT":
        return validate_jwt(match_str)
    return True
