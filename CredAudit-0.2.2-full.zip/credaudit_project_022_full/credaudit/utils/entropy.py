import math
def shannon_entropy(s: str) -> float:
    if not s: return 0.0
    freq = {}
    for ch in s.encode("utf-8", errors="ignore"):
        freq[ch] = freq.get(ch, 0) + 1
    length = sum(freq.values())
    ent = 0.0
    for c in freq.values():
        p = c / length
        ent -= p * math.log2(p)
    return ent
