import os

TEXT_EXTS = {".txt", ".json", ".env", ".log", ".cfg", ".ini", ".yaml", ".yml", ".py", ".js"}

def read_text_with_fallback(path: str):
    encodings = ["utf-8", "utf-16", "latin-1"]
    for enc in encodings:
        try:
            with open(path, "r", encoding=enc, errors="ignore") as f:
                return f.read()
        except Exception:
            continue
    return None

def extract_text_from_file(path: str):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in TEXT_EXTS:
            return read_text_with_fallback(path)
        if ext == ".docx":
            try:
                from docx import Document
            except Exception:
                return None
            try:
                doc = Document(path)
                return "\n".join([p.text for p in doc.paragraphs])
            except Exception:
                return None
        if ext == ".pdf":
            try:
                from pdfminer.high_level import extract_text
            except Exception:
                return None
            try:
                return extract_text(path)
            except Exception:
                return None
        if ext == ".xlsx":
            try:
                import openpyxl
            except Exception:
                return None
            try:
                wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
                out = []
                for ws in wb.worksheets:
                    for row in ws.iter_rows(values_only=True):
                        vals = [str(v) for v in row if v is not None]
                        if vals:
                            out.append(" ".join(vals))
                return "\n".join(out)
            except Exception:
                return None
        return read_text_with_fallback(path)
    except Exception:
        return None
